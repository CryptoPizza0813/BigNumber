#include "bignum_add_sub.c"

void bi_mulc(word x, word y, bigint** C);

void bi_mul(bigint* x, bigint* y, bigint** C);
void bi_kmul(bigint* x, bigint* y, bigint** C);
void bi_kmulc(bigint* x, bigint* y, bigint** C);

